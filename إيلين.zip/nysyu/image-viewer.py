from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.widget import Widget
from kivy.graphics import Line, Color

class ImageViewerApp(App):
    def build(self):
        # Define image paths
        self.image_paths = ["beach1.jpg", "beach2.jpg", "beach3.jpg", "beach4.jpg", "beach5.jpg"]

        # Create layout
        layout = BoxLayout(orientation="horizontal", spacing=10)

        # Add images to the layout
        for image_path in self.image_paths:
            image = Image(source=image_path)
            layout.add_widget(image)

        # Create a custom widget to draw lines
        self.line_widget = LineDrawingWidget(self.image_paths)
        layout.add_widget(self.line_widget)

        return layout

class LineDrawingWidget(Widget):
    def __init__(self, image_paths, **kwargs):
        super(LineDrawingWidget, self).__init__(**kwargs)
        self.image_paths = image_paths
        self.bind(pos=self.update_canvas, size=self.update_canvas)

    def update_canvas(self, *args):
        self.canvas.clear()

        # Get the positions of the images in the layout
        image_positions = []
        parent = self.parent
        for child in parent.children:
            if isinstance(child, Image):
                image_positions.append(child.pos)

        # Draw lines between the images
        with self.canvas:
            Color(1, 0, 0, 1)  # Set line color to red
            for i in range(len(image_positions)):
                start_pos = image_positions[i]
                end_pos = image_positions[(i + 1) % len(image_positions)]
                Line(points=[start_pos[0] + 100, start_pos[1] + 50, end_pos[0], end_pos[1] + 50], width=2)

if __name__ == "__main__":
    ImageViewerApp().run()